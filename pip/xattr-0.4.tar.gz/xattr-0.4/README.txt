xattr is a Python wrapper for Darwin's extended filesystem attributes

Extended attributes extend the basic attributes of files and directories
in the file system.  They are stored as name:data pairs associated with
file system objects (files, directories, symlinks, etc).

Extended attributes are currently only available on Darwin 8.0 and later.
This corresponds to Mac OS X 10.4 (Tiger).
