.. currentmodule:: kombu.messaging
.. _guide-producers:

===========
 Producers
===========

.. _producer-basics:

Basics
======


Serialization
=============

See :ref:`guide-serialization`.


Reference
=========

.. module:: kombu.messaging

.. autoclass:: Producer
    :noindex:
    :members:
