================
The Utils Module
================

.. automodule:: openstack_auth.utils
   :members:
